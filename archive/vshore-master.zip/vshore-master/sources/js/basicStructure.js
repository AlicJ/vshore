var textHome = "Home";
var textHelp = "Help"
var textAbout = "About Vshore"
var textJoin = "Join Us"
var textContact = "Contact Us"
var textAccount = "Your Account"
var textPrivacy = "Privacy"
var textAgreement = "Terms"

function appAlert(){
	alert("Sorry, the app is still under development, please stay tuned.");
}

var picCounter = 1;
var iPhonePic = window.setInterval(function(){
	if(picCounter == 5){
		picCounter = 1;
		$('.picSlide').fadeOut(1500);
	}else{
		$('.slide' + picCounter).fadeIn(1500);
		picCounter ++;
	}
},4000);

$(document).ready(function(){
    $('body').append('\
        <!-- Facebook like button-->\
        <div id="fb-root"></div>\
        <script>(function(d, s, id) {\
          var js, fjs = d.getElementsByTagName(s)[0];\
          if (d.getElementById(id)) return;\
          js = d.createElement(s); js.id = id;\
          js.src = "//connect.facebook.net/zh_CN/all.js#xfbml=1";\
          fjs.parentNode.insertBefore(js, fjs);\
        }(document, \'script\', \'facebook-jssdk\'));</script>\
        <!-- end of facebook-->\
    ');
    
    //output the header
    $('.header').append('\
    	<a class="logo" href="index.html" alt="Vshore logo"></a>\
        <div class="menu fr">\
		</div>\
	');
    switch(currentPage){
        case 1:
            $('.header .menu').append('\
                    <span class="lk on"><a href="index.html">'+textHome+'</a></span>\
                    <span class="lk"><a href="aboutus.html">'+textAbout+'</a></span>\
                    <span class="lk"><a href="joinus.html">'+textJoin+'</a></span>\
                    <span class="lk last"><a href="contactus.html">'+textContact+'</a></span>\
            ');
            break;
        case 2:
            $('.header .menu').append('\
                    <span class="lk"><a href="index.html">'+textHome+'</a></span>\
                    <span class="lk on"><a href="aboutus.html">'+textAbout+'</a></span>\
                    <span class="lk"><a href="joinus.html">'+textJoin+'</a></span>\
                    <span class="lk last"><a href="contactus.html">'+textContact+'</a></span>\
            ');
            break;
        case 3:
            $('.header .menu').append('\
                    <span class="lk"><a href="index.html">'+textHome+'</a></span>\
                    <span class="lk"><a href="aboutus.html">'+textAbout+'</a></span>\
                    <span class="lk on"><a href="joinus.html">'+textJoin+'</a></span>\
                    <span class="lk last"><a href="contactus.html">'+textContact+'</a></span>\
            ');
            break;
        case 4:
            $('.header .menu').append('\
                    <span class="lk"><a href="index.html">'+textHome+'</a></span>\
                    <span class="lk"><a href="aboutus.html">'+textAbout+'</a></span>\
                    <span class="lk"><a href="joinus.html">'+textJoin+'</a></span>\
                    <span class="lk on last"><a href="contactus.html">'+textContact+'</a></span>\
            ');
            break;
        default:
            $('.header .menu').append('\
                    <span class="lk"><a href="index.html">'+textHome+'</a></span>\
                    <span class="lk"><a href="aboutus.html">'+textAbout+'</a></span>\
                    <span class="lk"><a href="joinus.html">'+textJoin+'</a></span>\
                    <span class="lk last"><a href="contactus.html">'+textContact+'</a></span>\
            ');
    }

    //output the footer
    $('.footerGrey').append('\
        <div class="footerContent wrapper">\
            <div class="like facebook">\
                <div class="fb-like" data-href="https://www.vshore.com" data-send="false" data-layout="button_count" data-width="450" data-show-faces="true" data-font="arial"></div>\
            </div>\
            <div class="like twitter">\
                <a href="https://twitter.com/vshoreLLC" class="twitter-follow-button" data-show-count="true" data-show-screen-name="false" data-lang="en">Follow</a>\
                <script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>\
            </div>\
        </div>\
    ');
    switch (currentPage){
        case 5:
            $('.footerContent').append('\
                <div class="footerLinks">\
                    <span class="on"><a href="privacy.html">'+textPrivacy+'</a></span>\
                    <span><a href="useragreement.html">'+textAgreement+'</a></span>\
                </div>\
            ');
            break;
        case 6:
            $('.footerContent').append('\
                <div class="footerLinks">\
                    <span><a href="privacy.html">'+textPrivacy+'</a></span>\
                    <span class="on"><a href="useragreement.html">'+textAgreement+'</a></span>\
                </div>\
            ');
            break;
        default:
            $('.footerContent').append('\
                <div class="footerLinks">\
                    <span><a href="privacy.html">'+textPrivacy+'</a></span>\
                    <span><a href="useragreement.html">'+textAgreement+'</a></span>\
                </div>\
            ');
    }
    
    $('.footerLinks').append('\
        <span><a href="">© 2011-2013 Vshore Tech</a></span>\
    ');

});

    
